<?php
	ob_start(); // don't echo before headers
	
	class SynchronizedFile {
		private $semaphore;
		
		function __construct($path) {
			$this->semaphore = fopen($path . '.sem', 'w+');
		}
		
		function lock() {
			return flock($this->semaphore, LOCK_EX);
		}
		
		function release() {
			return flock($this->semaphore, LOCK_UN);
		}
	}
	
	/**
	 *	Starting at the position 0 (up to n-1; if it goes to n set it as 0 again):
	 *	1) If you already own a position, set it as reserved [exit]
	 *	2) If the current position is not reserved, it's yours [exit]
	 *	3) If the current position is reserved, set it as unreserved and set the position as the next one [return to step 2]
	 */
	class ClockQueue {
		private $path;
		private $entries;
		private $data; // newline included
		
		function __construct($queue_data_path, $entries, $data) {
			$this->path = $queue_data_path;
			$this->entries = $entries;
			$this->data = $data . PHP_EOL;
		}
		
		/**
		 *	The file follows this structure:
		 *
		 *	0: current pointer (0 to n-1)
		 *	1: is 0 position reserved?
		 *	2: 0 position data
		 *	3: is 1 position reserved?
		 *	4: 1 position data
		 *	...
		 *	2*(n-1)+1: is n-1 position reserved?
		 *	2*n: n-1 position data
		 */
		private function createFile() {
			$file = fopen($this->path, "w");
			$out = '0' . PHP_EOL; // pointer at first position
			for ($i = 0; $i < $this->entries; ++$i) $out .= '0' . PHP_EOL . PHP_EOL; // not used & null data
			fwrite($file, $out);
			fclose($file);
		}
		
		function getPointer($onNotAlready) {
			$sem = new SynchronizedFile($this->path);
			$sem->lock();
			
			if (!file_exists($this->path)) $this->createFile();
			
			$content = file($this->path);
			$ret = $this->alreadyReserved($content);
			$already = ($ret !== -1);
			if (!$already) {
				// run loop
				$index = intval($content[0]);
				while ($content[(2*$index)+1] === '1' . PHP_EOL) {
					$content[(2*$index)+1] = '0' . PHP_EOL;
					
					if (++$index === $this->entries) $index = 0;
				}
				
				// reserve
				$content[(2*$index)+1] = '1' . PHP_EOL;
				$content[2*($index+1)] = $this->data;
				$ret = $index;
				
				// set new index
				if (++$index === $this->entries) $index = 0;
				$content[0] = $index . PHP_EOL;
				
				// save
				$this->refreshFile($content);
			}
			
			if (!$already) $onNotAlready($ret);
			$sem->release();
			return $ret;
		}
		
		/**
		 *	Searches for the current data; if it's found it sets it back to used
		 *	@return -1 if none
		 */
		private function alreadyReserved($rows) {
			for ($i = 0; $i < $this->entries; ++$i) {
				if ($rows[2*($i+1)] === $this->data) {
					if ($rows[(2*$i)+1] !== '1' . PHP_EOL) {
						$rows[(2*$i)+1] = '1' . PHP_EOL;
						$this->refreshFile($rows);
					}
					return $i;
				}
			}
			return -1;
		}
		
		private function refreshFile($rows) {
			$file = fopen($this->path, "w");
			$out = '';
			foreach ($rows as $row) $out .= $row;
			fwrite($file, $out);
			fclose($file);
		}
	}
	
	function secureDie($error, ...$semaphores) {
		foreach ($semaphores as $semaphore) $semaphore->release();
		die($error);
	}
	
	// @author https://www.geeksforgeeks.org/copy-the-entire-contents-of-a-directory-to-another-directory-in-php/
	function custom_copy($src, $dst) {
		// open the source directory
		$dir = opendir($src);
	  
		// Make the destination directory if not exist
		@mkdir($dst);
	  
		// Loop through the files in source directory
		while( $file = readdir($dir) ) {
			if (( $file != '.' ) && ( $file != '..' )) {
				if ( is_dir($src . '/' . $file) ) {
					// Recursively calling custom copy function
					// for sub directory 
					custom_copy($src . '/' . $file, $dst . '/' . $file);
	  
				}
				else {
					copy($src . '/' . $file, $dst . '/' . $file);
				}
			}
		}
		closedir($dir);
	}

	function get_durability($used_item) {
		$json = file_get_contents('1.13_items.json');
		$json_data = json_decode($json,true);
		
		foreach($json_data as $item) {
			if (strcmp($used_item, $item['name']) == 0) {
				return $item['maxDurability'];
			}
		}

		return -1;
	}
	
	/* check arguments */
	
	if (!isset($_GET["format"]) || !is_numeric($_GET["format"])) die("format needs to be a number!");
	if (isset($_GET["custom_model_data"]) && !is_numeric($_GET["custom_model_data"])) die("custom_model_data needs to be a number!");
	if (isset($_GET["damage"]) && !is_numeric($_GET["damage"])) die("damage needs to be a number!");
	if (!isset($_GET["damage"]) && !isset($_GET["custom_model_data"])) die("damage or custom_model_data must be setted!");

	if (!isset($_GET["tool"])) die("You have to set a tool!");
	$tool = preg_replace("/[^a-zA-Z_]+/", "", $_GET["tool"]);
	if ($tool !== $_GET["tool"]) die("Invalid tool.");
	$tool = strtolower($tool); // Material#toString() is in capital leter

	$format = intval($_GET["format"]);
	
	$durability = (isset($_GET["damage"]) ? get_durability($tool) : 0);
	if ($durability === -1) die("Couldn't get the durability of the tool.");
	
	/* create files */
	
	// execute even after the user leave
	ignore_user_abort(true);
	set_time_limit(0);
	
	$queue = new ClockQueue("clock_queue.txt", 12, $_SERVER['QUERY_STRING']);
	$reserved_name = 'portalgun_' . $queue->getPointer(function($queue) {
		unlink('portalgun_' . $queue . '.zip'); // remove the .zip if it's new; that way if another enters and the new didn't generate the zip yet it will wait
	});
	
	$zipFile = $reserved_name . '.zip';
	$sem_zip = new SynchronizedFile($zipFile);
	
	if (file_exists($zipFile)) {
		// zip already created; we just need to echo the zip
		$sem_zip->lock();
	}
	else {
		$sem_folder = new SynchronizedFile($reserved_name);
		$sem_folder->lock();
		
		if (!file_exists($reserved_name)) custom_copy("portalgun", $reserved_name);
		
		$myfile = fopen("portalgun/pack.mcmeta", "w") or secureDie("Unable to open file!", $sem_folder);
		fwrite($myfile, '{
  "pack": {
    "pack_format": ' . $_GET["format"] . ',
    "description": "PortalGun texture pack"
  }
}');
		fclose($myfile);
		
		// delete previous files
		$files = glob('portalgun/assets/minecraft/models/item/*'); // get all file names
		foreach($files as $file) {
			if(is_file($file)) unlink($file); // delete
		}
		
		$myfile = fopen("portalgun/assets/minecraft/models/item/" . $tool . ".json", "w") or secureDie("Unable to open file!", $sem_folder);
		if (isset($_GET["custom_model_data"])) {
			fwrite($myfile, '{
  "parent": "minecraft:item/handheld",
  "textures": {
    "layer0": "minecraft:item/' . $tool . '"
  },
  "overrides": [
    { "predicate": { "custom_model_data": ' . $_GET["custom_model_data"] . ' }, "model": "portal_gun:portal_gun_orange" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 1) . ' }, "model": "portal_gun:portal_gun_blue" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 2) . ' }, "model": "portal_gun:laser_reciever" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 3) . ' }, "model": "portal_gun:laser_reciever_active" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 4) . ' }, "model": "portal_gun:laser_emmiter" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 5) . ' }, "model": "portal_gun:weighted_cube" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 6) . ' }, "model": "portal_gun:companion_cube" },
	{ "predicate": { "custom_model_data": ' . intval($_GET["custom_model_data"] + 7) . ' }, "model": "portal_gun:redirection_cube" }
  ]
}');
		}
		else {
			$folder = ($format > 3) ? 'item/' : 'items/'; // prior to 1.13 it was 'items', not 'item'
			fwrite($myfile, '{
  "parent": "minecraft:item/handheld",
  "textures": {
    "layer0": "minecraft:' . $folder . $tool . '"
  },
  "overrides": [
    { "predicate": { "damage": 0 }, "model": "item/' . $tool . '" },
    { "predicate": { "damaged": 0, "damage": ' . (floatval($_GET["damage"]) / $durability) . ' }, "model": "portal_gun:portal_gun_orange" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 1) / $durability) . ' }, "model": "portal_gun:portal_gun_blue" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 2) / $durability) . ' }, "model": "portal_gun:laser_reciever" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 3) / $durability) . ' }, "model": "portal_gun:laser_reciever_active" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 4) / $durability) . ' }, "model": "portal_gun:laser_emmiter" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 5) / $durability) . ' }, "model": "portal_gun:weighted_cube" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 6) / $durability) . ' }, "model": "portal_gun:companion_cube" },
    { "predicate": { "damaged": 0, "damage": ' . ((floatval($_GET["damage"]) + 7) / $durability) . ' }, "model": "portal_gun:redirection_cube" },
    { "predicate": { "damaged": 1 }, "model": "item/' . $tool . '" }
  ]
}');
		}
		fclose($myfile);
		
		
		/* create zip (from https://stackoverflow.com/a/4914807/9178470) */
		if (connection_aborted()) secureDie("Aborted", $sem_folder);
		
		$rootPath = realpath('portalgun');
		
		$sem_zip->lock();
		
		// Initialize archive object
		$zip = new ZipArchive();
		$zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);

		// Create recursive directory iterator
		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($rootPath),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ($files as $name => $file) {
			// Skip directories (they would be added automatically)
			if (!$file->isDir())
			{
				// Get real and relative path for current file
				$filePath = $file->getRealPath();
				$relativePath = substr($filePath, strlen($rootPath) + 1);

				// Add current file to archive
				$zip->addFile($filePath, $relativePath);
			}
		}
		$sem_folder->release(); // we're done with the folder

		// Zip archive will be created only after closing object
		$zip->close();
	}
	
	/* download file (from https://www.php.net/manual/es/function.readfile.php) */
	if (connection_aborted()) secureDie("Aborted", $sem_zip);
	
	error_reporting(0); // errors may corrupt the download
	ob_end_clean();
	
	$filesize = filesize($zipFile);
	
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="portalgun.zip"');
    header('Expires: 0' /*. gmdate('D, d M Y H:i:s \G\M\T', time())*/); // prevent cache
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . $filesize);
    header("Content-Range: 0-".($filesize-1)."/".$filesize); // https://stackoverflow.com/a/30569921/9178470
	flush();
	
    readfile($zipFile);
	flush();
	
	error_reporting(1);
	
	$sem_zip->release(); // we're done with the file
?>