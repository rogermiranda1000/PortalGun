<?php
	// Semaphore properties
	$key         = 123456;
	$max         = 1;
	$permissions = 0666;
	$autoRelease = 1;
	
	if (!function_exists('sem_get')) {
		function sem_get($key, $max, $permissions, $autoRelease) {
			if ($max != 1) die("Unsupported semaphore");
			return fopen(__FILE__ . '.sem.' . $key, 'w+');
		}
		function sem_acquire($sem_id) {
			return flock($sem_id, LOCK_EX);
		}
		function sem_release($sem_id) {
			return flock($sem_id, LOCK_UN);
		}
	}
	
	$semaphore = sem_get($key, $max, $permissions, $autoRelease);
	if (!$semaphore) die("Failed syncronization!");
	
	function secureDie($error) {
		sem_release($semaphore);
		die($error);
	}
	
	// TODO check for existant
	
	/* check arguments */
	
	if (!is_numeric($_GET["format"])) die("Format needs to be a number!");
	if (isset($_GET["custom_model_data"]) && !is_numeric($_GET["custom_model_data"])) die("custom_model_data needs to be a number!");
	if (isset($_GET["damage"]) && !preg_match("/[01](\.\d+)?/", $_GET["damage"])) die("Damage needs to be a float!");
	if (!isset($_GET["damage"]) && !isset($_GET["custom_model_data"])) die("Damage or custom_model_data must be setted!");
	$tool = preg_replace("/[^a-zA-Z_]+/", "", $_GET["tool"]);
	if ($tool !== $_GET["tool"]) die("Invalid tool");
	$tool = strtolower($tool); // Material#toString() is in capital leter
	$format = intval($_GET["format"]);
	
	/* create files */
	
	sem_acquire($semaphore);
	
	$myfile = fopen("portalgun/pack.mcmeta", "w") or secureDie("Unable to open file!");
	fwrite($myfile, '{
  "pack": {
    "pack_format": ' . $_GET["format"] . ',
    "description": "PortalGun texture pack"
  }
}');
	fclose($myfile);
	
	// delete previous files
	$files = glob('portalgun/assets/minecraft/models/item/*'); // get all file names
	foreach($files as $file) {
		if(is_file($file)) unlink($file); // delete
	}
	
	$myfile = fopen("portalgun/assets/minecraft/models/item/" . $tool . ".json", "w") or secureDie("Unable to open file!");
	if (isset($_GET["custom_model_data"])) {
		fwrite($myfile, '{
  "parent": "minecraft:item/handheld",
  "textures": {
    "layer0": "minecraft:item/' . $tool . '"
  },
  "overrides": [
    { "predicate": { "custom_model_data": ' . $_GET["custom_model_data"] . ' }, "model": "portal_gun:portal_gun" }
  ]
}');
	}
	else {
		$folder = ($format > 3) ? 'item/' : 'items/'; // prior to 1.13 it was 'items', not 'item'
		fwrite($myfile, '{
  "parent": "minecraft:item/handheld",
  "textures": {
    "layer0": "minecraft:' . $folder . $tool . '"
  },
  "overrides": [
    { "predicate": { "damage": 0 }, "model": "item/' . $tool . '" },
    { "predicate": { "damaged": 0, "damage": ' . $_GET["damage"] . ' }, "model": "portal_gun:portal_gun" },
    { "predicate": { "damaged": 1 }, "model": "item/' . $tool . '" }
  ]
}');
	}
	fclose($myfile);
	
	
	
	
	/* create zip (from https://stackoverflow.com/a/4914807/9178470) */
	
	$rootPath = realpath('portalgun');
	$zipFile = 'portalgun.zip';
	
	// Initialize archive object
	$zip = new ZipArchive();
	$zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);

	// Create recursive directory iterator
	$files = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator($rootPath),
		RecursiveIteratorIterator::LEAVES_ONLY
	);

	foreach ($files as $name => $file) {
		// Skip directories (they would be added automatically)
		if (!$file->isDir())
		{
			// Get real and relative path for current file
			$filePath = $file->getRealPath();
			$relativePath = substr($filePath, strlen($rootPath) + 1);

			// Add current file to archive
			$zip->addFile($filePath, $relativePath);
		}
	}

	// Zip archive will be created only after closing object
	$zip->close();
	
	
	
	
	
	/* download file (from https://www.php.net/manual/es/function.readfile.php) */
	
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($zipFile).'"');
    header('Expires: 0'); // TODO useful while deleting the file?
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($zipFile));
    readfile($zipFile);
	
	sem_release($semaphore);
?>